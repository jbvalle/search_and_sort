var searchData=
[
  ['randomizer_5f8_5f16_5f64_0',['randomizer_8_16_64',['../randomizer__8__16__64_8h.html#ae386b2dce50681712007b74fe6b355f9',1,'randomizer_8_16_64(int **input):&#160;randomizer_8_16_64.c'],['../randomizer__8__16__64_8c.html#ae386b2dce50681712007b74fe6b355f9',1,'randomizer_8_16_64(int **input):&#160;randomizer_8_16_64.c']]],
  ['randomizer_5fpt_1',['randomizer_pt',['../randomizer__pt_8h.html#ac28b64d15dfadffa71037609356be270',1,'randomizer_pt(int **input):&#160;randomizer_pt.c'],['../randomizer__pt_8c.html#ac28b64d15dfadffa71037609356be270',1,'randomizer_pt(int **input):&#160;randomizer_pt.c']]],
  ['reset_5fvalues_2',['reset_values',['../randomizer__pt_8h.html#a62c633362ff69bcbef7aefa25dae6b63',1,'reset_values(int **output, int **input, int exp, int i):&#160;randomizer_pt.c'],['../randomizer__pt_8c.html#a62c633362ff69bcbef7aefa25dae6b63',1,'reset_values(int **output, int **input, int exp, int i):&#160;randomizer_pt.c']]],
  ['reverse_3',['reverse',['../randomizer__pt_8h.html#a905b185a2769f7679b3ecf5a52eb0981',1,'reverse(int **input_pt, int index, int sizeof_array):&#160;randomizer_pt.c'],['../randomizer__pt_8c.html#a443ee242f095a57abab83a458a33dd25',1,'reverse(int **input, int index, int sizeof_array):&#160;randomizer_pt.c']]],
  ['run_5falgos_4',['run_algos',['../randomizer__pt_8h.html#a3dc939e27cdb431e94edf874458042f6',1,'run_algos(int **begarr_pt):&#160;randomizer_pt.c'],['../randomizer__pt_8c.html#a3dc939e27cdb431e94edf874458042f6',1,'run_algos(int **begarr_pt):&#160;randomizer_pt.c']]]
];
