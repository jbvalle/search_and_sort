var searchData=
[
  ['text_0',['text',['../structmenu.html#a5633b1433389cec21ade3811bbe9ca5b',1,'menu']]]
];
