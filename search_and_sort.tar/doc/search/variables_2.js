var searchData=
[
  ['symbol_0',['symbol',['../structmenu.html#af7565614b2ea8e3f98b39303ae09ebca',1,'menu']]]
];
