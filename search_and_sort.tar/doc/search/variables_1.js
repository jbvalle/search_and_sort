var searchData=
[
  ['next_0',['next',['../structnode.html#a0dc1b6470487aa86d9936e3cab8b95be',1,'node']]],
  ['num_1',['num',['../structnode.html#a86cf672daa4e0ad11ad10efc894d19c8',1,'node']]]
];
