var searchData=
[
  ['color_0',['COLOR',['../menu_8c.html#a4b5014034c9aac136ab8c82c2d16dc82',1,'COLOR():&#160;menu.c'],['../randomizer__8__16__64_8c.html#a4b5014034c9aac136ab8c82c2d16dc82',1,'COLOR():&#160;randomizer_8_16_64.c'],['../randomizer__pt_8c.html#a4b5014034c9aac136ab8c82c2d16dc82',1,'COLOR():&#160;randomizer_pt.c'],['../sortcheck_8c.html#a4b5014034c9aac136ab8c82c2d16dc82',1,'COLOR():&#160;sortcheck.c'],['../testing_8c.html#a4b5014034c9aac136ab8c82c2d16dc82',1,'COLOR():&#160;testing.c']]]
];
