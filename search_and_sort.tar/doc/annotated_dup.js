var annotated_dup =
[
    [ "menu", "structmenu.html", "structmenu" ],
    [ "node", "structnode.html", "structnode" ]
];