var testing_8c =
[
    [ "COLOR", "testing_8c.html#a4b5014034c9aac136ab8c82c2d16dc82", null ],
    [ "RESET", "testing_8c.html#ab702106cf3b3e96750b6845ded4e0299", null ],
    [ "bs", "testing_8c.html#a3fc7e7bc2964829722e1f76deec770d6", null ],
    [ "is", "testing_8c.html#a01e5faf4c26f11496f8d85e16ba4a90f", null ],
    [ "ms", "testing_8c.html#ae563dc1cfab457094b404dfbcb2e7b88", null ],
    [ "qs", "testing_8c.html#a0f52cda2ab6e039e5cd00670c1d846d2", null ]
];