var menu_8c =
[
    [ "COLOR", "menu_8c.html#a4b5014034c9aac136ab8c82c2d16dc82", null ],
    [ "RESET", "menu_8c.html#ab702106cf3b3e96750b6845ded4e0299", null ],
    [ "parse_input", "menu_8c.html#a483ad615df99d6fd8f1477824e3a3520", null ],
    [ "show_menu", "menu_8c.html#af67480724089637b55a8148566870f16", null ],
    [ "mmenu", "menu_8c.html#a39fdd338c49a2bb31b0b9d3c749490ea", null ]
];