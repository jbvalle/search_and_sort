var structnode =
[
    [ "next", "structnode.html#a0dc1b6470487aa86d9936e3cab8b95be", null ],
    [ "num", "structnode.html#a86cf672daa4e0ad11ad10efc894d19c8", null ]
];