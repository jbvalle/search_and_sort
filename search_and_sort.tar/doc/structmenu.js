var structmenu =
[
    [ "symbol", "structmenu.html#af7565614b2ea8e3f98b39303ae09ebca", null ],
    [ "text", "structmenu.html#a5633b1433389cec21ade3811bbe9ca5b", null ]
];