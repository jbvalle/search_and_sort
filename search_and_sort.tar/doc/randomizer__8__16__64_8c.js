var randomizer__8__16__64_8c =
[
    [ "COLOR", "randomizer__8__16__64_8c.html#a4b5014034c9aac136ab8c82c2d16dc82", null ],
    [ "RESET", "randomizer__8__16__64_8c.html#ab702106cf3b3e96750b6845ded4e0299", null ],
    [ "free_8_16_64", "randomizer__8__16__64_8c.html#a25b0d9634537e3b6e176a45b33f0a428", null ],
    [ "randomizer_8_16_64", "randomizer__8__16__64_8c.html#ae386b2dce50681712007b74fe6b355f9", null ],
    [ "show_8_16_64", "randomizer__8__16__64_8c.html#a5ff94b4c2f9728e371dad1320ce882bc", null ]
];