var sortcheck_8c =
[
    [ "COLOR", "sortcheck_8c.html#a4b5014034c9aac136ab8c82c2d16dc82", null ],
    [ "RESET", "sortcheck_8c.html#ab702106cf3b3e96750b6845ded4e0299", null ],
    [ "sortcheck", "sortcheck_8c.html#aef341bab4007b5b2179ea4fe2420da91", null ]
];