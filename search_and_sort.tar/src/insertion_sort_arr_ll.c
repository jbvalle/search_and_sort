/**
 * @brief This Module includes all functions needed for performing a cpu runtime measurement assessing the performance of the insertionsort algorithm applied on an array and a linked list
 * @file insertion_sort_arr_ll.c
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "../include/node_t.h"
#include "../include/randomizer_8_16_64.h"
#include "../include/randomizer_pt.h"
#include "../include/insertionsort.h"
#include "../include/sortcheck.h"
#include "../include/mergesort.h"
#include "../include/search_index.h"
#include "../include/quicksort.h"

/**
 *@brief This function appends a new node with a given number element
 *@param[in] head Head of current list
 *@param[in] num Number element of new node
 *
 */
void append_node(node_t **head, int num){

    node_t *ptr = *head;

    node_t *new = malloc(sizeof(node_t));
    new->num = num;
    new->next = NULL;

    if(*head == NULL){

        *head = new;
        return;
    }

    for(; ptr->next != NULL; ptr = ptr->next);
    
    ptr->next = new;
}

/**
 *@brief Appends new nodes with provided number element from randomized array
 *@param[in] head Current head of list 
 *@param[in] arr Array of randomized numbers
 *@param[in] size Array size 
 *
 */
void populate_list(node_t **head, int *arr, int size){

   for(int i = 0; i < size; i++)append_node(head, arr[i]); 

}

/**
 *@brief This function inserts the new node in an alphabetical order
 *@param[in] sorted Head of sorted list
 *@param[in] new Current node element  
 *
 */
void sorted_insert(node_t **sorted, node_t *new){


    //1. Checks if first element is null or if first element's word is a 'subsequent' word of new
    if((*sorted) == NULL || ((*sorted)->num) >= new->num){

        //2. Stack new word unto list if first element is either Null or a subsequent word 
        new->next = *sorted;
        *sorted = new;
    }else{

        //3. Traverse through list until elements list is a subsequent element to new element
        node_t *curr_ptr = *sorted;

        while(curr_ptr->next != NULL && (curr_ptr->next->num <= new->num)){
            
            curr_ptr = curr_ptr->next;
        }

        //4. Insert new element behind the supposedly subsequent list's element
        new->next = curr_ptr->next;
        curr_ptr->next = new;
    }
}


/**
 *@brief This function traverses though list and adds any subsequent word into the sorted list
 *@param[in] head Head of current bucket
 */
void insertionSort(node_t **head){


    //1. Initialize head of sorted list
    node_t *sorted = NULL;

    node_t *curr_ptr = *head;

    //2. Traverse through list and add subsequent elements to the sorted list
    while(curr_ptr != NULL){

        node_t *temp = curr_ptr->next;

        sorted_insert(&sorted, curr_ptr);
        
        curr_ptr = temp;
    }

    //3. Assign new head of sorted list to original head
    *head = sorted;
}

/** @brief Function frees dynamically allocated memory. 
 * @param[in] head Head of current list
 * 
 */
void free_list(node_t *head){

    node_t *ptr = head;

    while(ptr != NULL){

        node_t *temp = ptr->next;
        free(ptr);
        ptr = temp;
    }
}

/**
 *@brief This function performs the complete performance test of insertionsort algorithm for lists and arrays
 *
 */
void insertionsort_arr_ll(){

    //===================================================
    //1. Insertionsort ARRAYS-LINKED-LIST Perfomance test
    //===================================================
    //Saves CPU Runtime value of a single function
    double pt_cpu_time_sec[2] = {0, 0};
    //Saves CPU Init value of a single function
    double pt_init_time_sec[2] = {0, 0};


    //Save temporary clocks at current time
    clock_t cpu_time_clk;

    clock_t init_time_clk;

    //Allocate HEAD Node for Linked list
    node_t *head = NULL;
    //Allocate Memory for Randomized ARRAY
    int **input_pt = (int **)malloc(7 * sizeof(int *));

    //Measure CPU TIME Iinit for Array
    init_time_clk = clock();
    randomizer_pt(input_pt);
    init_time_clk = clock() - init_time_clk;

    pt_init_time_sec[0] = (double)init_time_clk/(double)CLOCKS_PER_SEC;


    //Fill linked list with values of randomized list of size 2048
    //Measure CPU TIME Iinit for Linked list
    init_time_clk = clock();
    init_time_clk = clock();
    populate_list(&head, input_pt[search_index(2048)], 2048);
    init_time_clk = clock() - init_time_clk;

    pt_init_time_sec[1] = ((double)init_time_clk/(double)CLOCKS_PER_SEC)+pt_init_time_sec[0];

    //==============================================
    //2. INSERTION SORT FOR LINKED LIST 
    //==============================================
    //Measure Clock at current time
    cpu_time_clk = clock();
    //Perform Insertionsort for Linked List
    insertionSort(&head);
    ///Measure Clock at current time
    cpu_time_clk = clock() - cpu_time_clk;

    pt_cpu_time_sec[0] = (double)cpu_time_clk/(double)CLOCKS_PER_SEC;
    //==============================================

    //==============================================
    //3. INSERTION SORT FOR ARRAY
    //==============================================
    //Measure Clock at current time
    cpu_time_clk = clock();
    //Perform Insertionsort for Array
    insertionsort(input_pt, 2048);

    ///Measure Clock at current time
    cpu_time_clk = clock() - cpu_time_clk;
  
    pt_cpu_time_sec[1] = (double)cpu_time_clk/(double)CLOCKS_PER_SEC;
    //==============================================

    //Show list for linked list
    show_randomizer_pt_list(head, search_index(2048),15);

    //Show list of array
    show_randomizer_pt_index(input_pt, search_index(2048),15);
    
    printf("\033[1;93m");
  printf("\n\n+---------------------------------------------------------------------+");
    printf("\n| INIT-TIME-LINKED-LIST[ms]:%7.3fms | INIT-TIME-ARRAY[ms]:%7.3fms |", pt_init_time_sec[1]*1000., pt_init_time_sec[0]*1000.);
    printf("\n+---------------------------------------------------------------------+\n");
    printf("\033[0m");

    printf("\033[1;93m");
    printf("\n+-----------------------------------------------------------------+");
    printf("\n| RUNTIME-LINKED-LIST[ms]:%7.3fms | RUNTIME-ARRAY[ms]:%7.3fms |", pt_cpu_time_sec[0]*1000., pt_cpu_time_sec[1]*1000.);
    printf("\n+-----------------------------------------------------------------+\n");
    printf("\033[0m");

    free_pt(input_pt); 
    free_list(head);
}
