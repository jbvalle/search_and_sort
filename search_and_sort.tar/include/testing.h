/** @brief Header file for testing module.
 * @file testing.h
 * 
 */
#ifndef TESTING_H
#define TESTING_H

void bs();
void is();
void ms();
void qs();

#endif
