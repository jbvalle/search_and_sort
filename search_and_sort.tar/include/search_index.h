/** @brief Header file for index search module. 
 * @file search_index.h
 * 
 */
#ifndef SEARCH_INDEX_H
#define SEARCH_INDEX_H


int search_index(int num);

#endif
