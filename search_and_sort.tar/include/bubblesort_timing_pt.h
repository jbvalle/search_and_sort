/** @brief Header file for bubblesort performance test.
 *@file bubblesort_timing_pt.h
 *
 */
#ifndef BUBBLESORT_TIMING_PT_H
#define BUBBLESORT_TIMING_PT_H

void bubblesort_pt(int *input);

void bubblesort_timing_pt(int *);
#endif
