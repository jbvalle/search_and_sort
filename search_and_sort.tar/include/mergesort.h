/** @brief Header file for mergesort module.  
 * @file mergesort.h
 * 
 */

#ifndef MERGESORT_H
#define MERGESORT_H


void merge(int **input, int low, int mid, int high, int index);
void mergeSort(int **input, int l, int r, int index);
#endif
