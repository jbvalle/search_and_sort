/** @brief Header file for insertionsort module. 
 * @file insertionsort.h
 * 
 */
#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H


void insertionsort(int **input, int sizeof_array);

#endif
