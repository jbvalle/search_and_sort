/** @brief Header file for sortcheck module.
 * @file sortcheck.h
 * 
 */

#ifndef SORTCHECK_H
#define SORTCHECK_H


int sortcheck(int **input, int sizeof_array);
#endif
