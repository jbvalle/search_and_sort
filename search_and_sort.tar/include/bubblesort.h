/** @brief Header file for bubblesort module. 
 * @file bubblesort.h
 * 
 */

#ifndef BUBBLESORT_H
#define BUBBLESORT_H


void bubblesort(int **input, int sizeof_array);

#endif
